﻿namespace HomeOfPandaEyes.StockLearning.Membership {
    export interface ForgotPasswordRequest extends Serenity.ServiceRequest {
        Email?: string;
    }
}

