﻿namespace HomeOfPandaEyes.StockLearning {
    export interface GetNextNumberResponse extends Serenity.ServiceResponse {
        Number?: number;
        Serial?: string;
    }
}

