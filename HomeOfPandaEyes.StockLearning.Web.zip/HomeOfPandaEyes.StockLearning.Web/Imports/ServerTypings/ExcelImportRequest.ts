﻿namespace HomeOfPandaEyes.StockLearning {
    export interface ExcelImportRequest extends Serenity.ServiceRequest {
        FileName?: string;
    }
}

