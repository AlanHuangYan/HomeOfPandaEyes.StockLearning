﻿namespace HomeOfPandaEyes.StockLearning.Common {
    export interface UserPreferenceRetrieveResponse extends Serenity.ServiceResponse {
        Value?: string;
    }
}

