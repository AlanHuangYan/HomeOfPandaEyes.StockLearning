﻿namespace HomeOfPandaEyes.StockLearning.Administration {
    export interface UserRoleListResponse extends Serenity.ListResponse<number> {
    }
}

