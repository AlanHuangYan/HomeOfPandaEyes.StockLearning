﻿namespace HomeOfPandaEyes.StockLearning.Administration {
    export interface RolePermissionListResponse extends Serenity.ListResponse<string> {
    }
}

