﻿
namespace HomeOfPandaEyes.StockLearning.Administration
{
    using Serenity.Services;

    public class RolePermissionListResponse : ListResponse<string>
    {
    }
}