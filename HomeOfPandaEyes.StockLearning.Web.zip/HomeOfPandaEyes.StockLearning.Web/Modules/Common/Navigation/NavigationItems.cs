﻿using Serenity.Navigation;
using Administration = HomeOfPandaEyes.StockLearning.Administration.Pages;

[assembly: NavigationLink(1000, "Dashboard", url: "~/", permission: "", icon: "fa-tachometer")]
