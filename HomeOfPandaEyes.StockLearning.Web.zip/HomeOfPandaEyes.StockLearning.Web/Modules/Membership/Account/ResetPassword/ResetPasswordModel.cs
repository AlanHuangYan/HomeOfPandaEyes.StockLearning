﻿
namespace HomeOfPandaEyes.StockLearning.Membership
{
    public class ResetPasswordModel
    {
        public string Token { get; set; }
    }
}