﻿
namespace HomeOfPandaEyes.StockLearning
{
    public class EnvironmentSettings
    {
        public string SiteExternalUrl { get; set; }
    }
}